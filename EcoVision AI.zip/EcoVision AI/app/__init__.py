"""EcoVision AI package"""
