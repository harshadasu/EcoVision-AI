@echo off
echo ==========================================
echo   EcoVision AI - Starting Mobile App
echo ==========================================
cd /d "%~dp0mobile"

echo.
echo Choose your target platform:
echo [1] Windows Desktop
echo [2] Chrome Web
echo [3] Android (Device / Emulator)
echo.
set /p target="Enter choice (1, 2, or 3, default is 1): "

if "%target%"=="2" (
    echo Starting on Chrome Web...
    flutter run -d chrome
) else if "%target%"=="3" (
    echo Starting on Android...
    flutter run -d android
) else (
    echo Starting on Windows Desktop...
    flutter run -d windows
)

pause
